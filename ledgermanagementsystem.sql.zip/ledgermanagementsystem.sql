-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2026 at 11:12 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ledgermanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) NOT NULL,
  `address` text DEFAULT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `country` varchar(155) DEFAULT NULL,
  `ComName` varchar(155) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `country`, `ComName`, `role_id`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'imranertaza12@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Syed Imran Ertaza', 1924329315, 'Noapara, Abhaynagar, Jessore', 'profile_1664976903_39bd3bf1ddc2da4682f0.jpg', NULL, NULL, 1, '1', '2023-08-06 10:35:27', 1, 1, '2023-08-06 10:35:27', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `account_no` bigint(20) NOT NULL,
  `balance` double UNSIGNED NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_id`, `sch_id`, `name`, `account_no`, `balance`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(12, 3, 'IFIC Bank', 55235235235, 5500, '1', '2026-03-08 11:00:26', 2, NULL, '2026-03-08 13:04:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bank_deposit`
--

CREATE TABLE `bank_deposit` (
  `dep_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` double UNSIGNED NOT NULL,
  `commont` text DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank_deposit`
--

INSERT INTO `bank_deposit` (`dep_id`, `sch_id`, `bank_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(12, 3, 12, 10000, '', '2026-03-08 11:01:05', 2, NULL, '2026-03-08 12:54:06', NULL, NULL),
(13, 3, 12, 500, '', '2026-03-08 12:36:25', 2, NULL, '2026-03-08 12:36:25', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bank_withdraw`
--

CREATE TABLE `bank_withdraw` (
  `wthd_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `amount` double UNSIGNED NOT NULL,
  `commont` text DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bank_withdraw`
--

INSERT INTO `bank_withdraw` (`wthd_id`, `sch_id`, `bank_id`, `amount`, `commont`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(8, 3, 12, 5000, '', '2026-03-08 12:56:32', 2, NULL, '2026-03-08 13:04:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `image` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `chaque`
--

CREATE TABLE `chaque` (
  `chaque_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `chaque_number` int(11) NOT NULL,
  `to_name` varchar(155) DEFAULT NULL,
  `to` int(11) DEFAULT NULL,
  `from_name` varchar(155) DEFAULT NULL,
  `from` int(11) DEFAULT NULL,
  `from_loan_provider` int(11) DEFAULT NULL,
  `amount` float UNSIGNED NOT NULL,
  `issue_date` date NOT NULL,
  `account_number` int(11) DEFAULT NULL,
  `status` enum('Pending','Bounce','Approved') NOT NULL DEFAULT 'Pending',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_name` varchar(55) NOT NULL,
  `father_name` varchar(55) DEFAULT NULL,
  `mother_name` varchar(55) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `present_address` text DEFAULT NULL,
  `age` int(10) UNSIGNED DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `pic` varchar(55) DEFAULT NULL,
  `nid` varchar(155) DEFAULT NULL,
  `cus_type_id` int(11) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `balance` double NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `sch_id`, `customer_name`, `father_name`, `mother_name`, `address`, `present_address`, `age`, `mobile`, `pic`, `nid`, `cus_type_id`, `status`, `balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(28, 3, 'Sumon', NULL, NULL, NULL, NULL, NULL, '1923149437', NULL, NULL, 28, '1', 0, '2026-03-08 04:23:52', 2, 2, '2026-03-08 16:25:00', NULL, NULL),
(29, 3, 'Sumon', NULL, NULL, NULL, NULL, NULL, '19231494366', NULL, NULL, 28, '1', 500.5, '2026-03-09 11:21:29', 2, 2, '2026-03-09 12:27:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_type`
--

CREATE TABLE `customer_type` (
  `cus_type_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `type_name` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_type`
--

INSERT INTO `customer_type` (`cus_type_id`, `sch_id`, `type_name`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(28, 3, 'Reguler', '2026-03-08 04:23:40', 2, NULL, '2026-03-08 16:23:40', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `salary` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `balance` float UNSIGNED DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `sch_id`, `name`, `salary`, `age`, `balance`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(8, 3, 'murad', 5000, 28, 4000, '1', '2026-03-08 10:42:48', 2, 2, '2026-03-08 11:01:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gen_settings`
--

CREATE TABLE `gen_settings` (
  `settings_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gen_settings`
--

INSERT INTO `gen_settings` (`settings_id`, `sch_id`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(11, 2, 'barcode_img_size', '100', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(12, 2, 'barcode_type', 'C128A', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(13, 2, 'business_type', 'Ownership business', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(14, 2, 'currency', 'BDT', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(15, 2, 'currency_before_symbol', '৳', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(16, 2, 'currency_after_symbol', '/-', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(17, 2, 'running_year', '2018-2019', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(18, 2, 'disable_frontend', '0', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(19, 2, 'phone_code', '880', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(20, 2, 'country', 'Bangladesh', '2023-10-02 19:24:29', NULL, NULL, '2023-10-02 19:24:29', NULL, NULL),
(21, 3, 'barcode_img_size', '100', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(22, 3, 'barcode_type', 'C128A', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(23, 3, 'business_type', 'Ownership business', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(24, 3, 'currency', 'BDT', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(25, 3, 'currency_before_symbol', '৳', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(26, 3, 'currency_after_symbol', '/-', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(27, 3, 'running_year', '2018-2019', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(28, 3, 'disable_frontend', '0', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(29, 3, 'phone_code', '880', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(30, 3, 'country', 'Bangladesh', '2023-10-03 09:36:23', NULL, NULL, '2023-10-03 09:36:23', NULL, NULL),
(31, 3, 'edit_permission_expire', '10', '2025-05-19 19:50:50', NULL, NULL, '2025-05-20 11:49:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gen_settings_super`
--

CREATE TABLE `gen_settings_super` (
  `settings_id_sup` int(10) UNSIGNED NOT NULL,
  `label` varchar(155) NOT NULL,
  `value` varchar(155) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gen_settings_super`
--

INSERT INTO `gen_settings_super` (`settings_id_sup`, `label`, `value`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'loading_message', 'Please wait until it is processing...', '2023-09-02 10:22:44', 0, NULL, '2023-09-02 10:22:44', NULL, NULL),
(2, 'site_title', 'Shohoz Hishab | Accounting management system', '2023-09-02 10:22:44', 0, NULL, '2023-09-02 10:22:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger`
--

CREATE TABLE `ledger` (
  `ledg_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger`
--

INSERT INTO `ledger` (`ledg_id`, `sch_id`, `customer_id`, `invoice_id`, `service_invoice_id`, `trans_id`, `rtn_sale_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(55, 3, 28, 15, NULL, NULL, NULL, NULL, 'Sales Cash Due', 'Dr.', 1500, 1500, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(56, 3, 28, 15, NULL, NULL, NULL, NULL, 'Sales Cash Pay', 'Cr.', 1500, 0, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(57, 3, 28, NULL, NULL, NULL, 2, NULL, 'Return Sale Product', 'Cr.', 1500, -1500, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL),
(58, 3, 28, NULL, NULL, NULL, 2, NULL, 'Return Sale Product cash Pay', 'Dr.', 1500, 0, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL),
(59, 3, 29, NULL, NULL, 124, NULL, NULL, 'test', 'Dr.', 500.5, 500.5, '2026-03-09 11:21:40', 2, NULL, '2026-03-09 12:27:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_bank`
--

CREATE TABLE `ledger_bank` (
  `ledgBank_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger_bank`
--

INSERT INTO `ledger_bank` (`ledgBank_id`, `sch_id`, `bank_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `service_invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(33, 3, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Dr.', 10000, 10000, '2026-03-08 11:01:05', NULL, NULL, '2026-03-08 12:54:06', NULL, NULL),
(34, 3, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Dr.', 500, 10500, '2026-03-08 12:36:25', NULL, NULL, '2026-03-08 12:54:06', NULL, NULL),
(35, 3, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Withdraw', 'Cr.', 5000, 5500, '2026-03-08 12:56:32', NULL, NULL, '2026-03-08 13:04:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_capital`
--

CREATE TABLE `ledger_capital` (
  `capital_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger_capital`
--

INSERT INTO `ledger_capital` (`capital_id`, `sch_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(41, 3, NULL, 'test', 'Cr.', 50000, -50000, '2026-03-08 10:42:33', 2, NULL, '2026-03-08 10:42:33', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_discount`
--

CREATE TABLE `ledger_discount` (
  `discount_ledg_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ledger_employee`
--

CREATE TABLE `ledger_employee` (
  `ledg_emp_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger_employee`
--

INSERT INTO `ledger_employee` (`ledg_emp_id`, `sch_id`, `employee_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(9, 3, 8, 121, NULL, 'Salary', 'Dr.', 4000, 4000, '2026-03-08 10:43:03', 2, NULL, '2026-03-08 11:01:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_expense`
--

CREATE TABLE `ledger_expense` (
  `ledg_exp_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `memo_number` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ledger_loan`
--

CREATE TABLE `ledger_loan` (
  `ledg_loan_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `loan_pro_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ledger_loan`
--

INSERT INTO `ledger_loan` (`ledg_loan_id`, `sch_id`, `loan_pro_id`, `money_receipt_id`, `trans_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(29, 3, 22, NULL, 122, NULL, '10000', 'Cr.', 10000.5, -10000.5, '2026-03-08 12:33:05', 2, NULL, '2026-03-09 10:06:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_nagodan`
--

CREATE TABLE `ledger_nagodan` (
  `ledg_nagodan_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `loan_pro_id` int(11) DEFAULT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_nagodan`
--

INSERT INTO `ledger_nagodan` (`ledg_nagodan_id`, `sch_id`, `customer_id`, `bank_id`, `loan_pro_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `rtn_sale_id`, `chaque_id`, `invoice_id`, `service_invoice_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(69, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test', 'Dr.', 50000, 50000, '2026-03-08 10:42:33', 2, NULL, '2026-03-08 10:42:33', NULL, NULL),
(70, 3, NULL, NULL, NULL, NULL, NULL, 121, NULL, NULL, NULL, NULL, NULL, 'Salary', 'Cr.', 4000, 46000, '2026-03-08 10:43:03', 2, NULL, '2026-03-08 11:01:29', NULL, NULL),
(71, 3, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Cr.', 10000, 36000, '2026-03-08 11:01:05', NULL, NULL, '2026-03-08 12:54:06', NULL, NULL),
(72, 3, NULL, NULL, NULL, NULL, NULL, 122, NULL, NULL, NULL, NULL, NULL, '10000', 'Dr.', 10000.5, 38000.5, '2026-03-08 12:33:05', 2, NULL, '2026-03-09 10:06:06', NULL, NULL),
(73, 3, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Deposit', 'Cr.', 500, 45499.5, '2026-03-08 12:36:25', NULL, NULL, '2026-03-09 10:06:06', NULL, NULL),
(74, 3, NULL, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Bank Cash Withdraw', 'Dr.', 5000, 50500.5, '2026-03-08 12:56:32', NULL, NULL, '2026-03-09 10:06:06', NULL, NULL),
(75, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, NULL, 'Sales Cash Pay', 'Dr.', 1500, 52000.5, '2026-03-08 04:24:15', 2, NULL, '2026-03-09 10:06:06', NULL, NULL),
(76, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, 'Return Sale Cash Pay', 'Cr.', 1500, 50499.5, '2026-03-08 04:25:00', 2, NULL, '2026-03-09 10:06:06', NULL, NULL),
(77, 3, NULL, NULL, NULL, NULL, NULL, 123, NULL, NULL, NULL, NULL, NULL, 'test', 'Cr.', 500, 50000.5, '2026-03-09 11:21:16', 2, NULL, '2026-03-09 11:22:44', NULL, NULL),
(78, 3, NULL, NULL, NULL, NULL, NULL, 124, NULL, NULL, NULL, NULL, NULL, 'test', 'Cr.', 500.5, 49501, '2026-03-09 11:21:40', 2, NULL, '2026-03-09 12:27:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_other_sales`
--

CREATE TABLE `ledger_other_sales` (
  `ledg_oth_sales_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ledger_profit`
--

CREATE TABLE `ledger_profit` (
  `profit_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_profit`
--

INSERT INTO `ledger_profit` (`profit_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(14, 3, 15, NULL, 'Sales profit get', 'Cr.', 100, -100, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(15, 3, NULL, 2, 'Return Profit', 'Dr.', 100, 0, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_purchase`
--

CREATE TABLE `ledger_purchase` (
  `ledgPurch_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_purchase`
--

INSERT INTO `ledger_purchase` (`ledgPurch_id`, `sch_id`, `purchase_id`, `rtn_purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(12, 3, 14, NULL, 'New purchase amount', 'Dr.', 140000, 140000, '2026-03-08 04:22:54', 2, NULL, '2026-03-08 16:22:54', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_sales`
--

CREATE TABLE `ledger_sales` (
  `ledgSale_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_sales`
--

INSERT INTO `ledger_sales` (`ledgSale_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(14, 3, 15, NULL, 'New Sale amount', 'Cr.', 1500, -1500, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(15, 3, NULL, 2, 'return sale', 'Dr.', 1500, 0, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_service_charge`
--

CREATE TABLE `ledger_service_charge` (
  `ledger_service_charge_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `service_invoice_id` int(11) DEFAULT NULL,
  `particulars` text NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ledger_stock`
--

CREATE TABLE `ledger_stock` (
  `stock_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `rtn_sale_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_stock`
--

INSERT INTO `ledger_stock` (`stock_id`, `sch_id`, `invoice_id`, `rtn_sale_id`, `purchase_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(25, 3, NULL, NULL, 14, 'New purchase amount', 'Dr.', 140000, 140000, '2026-03-08 04:22:54', 2, NULL, '2026-03-08 16:22:54', NULL, NULL),
(26, 3, 15, NULL, NULL, 'Sale amount', 'Cr.', 1400, 138600, '2026-03-08 04:24:15', 2, NULL, '2026-03-08 16:24:15', NULL, NULL),
(27, 3, NULL, 2, NULL, 'Return sale', 'Dr.', 1400, 140000, '2026-03-08 04:25:00', 2, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_suppliers`
--

CREATE TABLE `ledger_suppliers` (
  `ledg_sup_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `money_receipt_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `rtn_purchase_id` int(11) DEFAULT NULL,
  `chaque_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float UNSIGNED NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_suppliers`
--

INSERT INTO `ledger_suppliers` (`ledg_sup_id`, `sch_id`, `supplier_id`, `money_receipt_id`, `purchase_id`, `trans_id`, `rtn_purchase_id`, `chaque_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(45, 3, 23, NULL, 14, NULL, NULL, NULL, 'Purchase Cash Due', 'Cr.', 140000, -140000, '2026-03-08 04:22:54', 2, NULL, '2026-03-08 16:22:54', NULL, NULL),
(46, 3, 24, NULL, NULL, 123, NULL, NULL, 'test', 'Dr.', 500, 500, '2026-03-09 11:21:15', 2, NULL, '2026-03-09 11:22:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ledger_vat`
--

CREATE TABLE `ledger_vat` (
  `ledg_vat_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `vat_id` int(11) NOT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `particulars` text COLLATE utf8_unicode_ci NOT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cr.',
  `amount` float NOT NULL,
  `rest_balance` float NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ledger_vat`
--

INSERT INTO `ledger_vat` (`ledg_vat_id`, `sch_id`, `vat_id`, `invoice_id`, `trans_id`, `particulars`, `trangaction_type`, `amount`, `rest_balance`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(14, 3, 2, 15, NULL, 'Return Sale Vat return', 'Dr.', 0, 0, '2026-03-08 16:25:00', 3, NULL, '2026-03-08 16:25:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `license`
--

CREATE TABLE `license` (
  `lic_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `lic_key` text COLLATE utf8_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `license`
--

INSERT INTO `license` (`lic_id`, `sch_id`, `lic_key`, `start_date`, `end_date`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 2, '651ac4dd948c7', '2023-10-02', '2026-10-06', '1', '2023-10-02 19:25:49', NULL, NULL, '2023-10-02 19:25:49', NULL, NULL),
(3, 3, '651b8c5336dc2', '2023-10-03', '2030-12-31', '1', '2023-10-03 09:36:51', NULL, NULL, '2023-10-03 09:36:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `loan_provider`
--

CREATE TABLE `loan_provider` (
  `loan_pro_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `balance` float NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `loan_provider`
--

INSERT INTO `loan_provider` (`loan_pro_id`, `sch_id`, `name`, `phone`, `address`, `balance`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(22, 3, 'murad', '01923191919', NULL, -10000.5, '1', '2026-03-08 12:32:45', 2, 2, '2026-03-09 10:06:06', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
(3, '2023-08-06-034752', 'App\\Database\\Migrations\\Admin', 'default', 'App', 1691296280, 1),
(4, '2023-08-06-050108', 'App\\Database\\Migrations\\Bank', 'default', 'App', 1691591167, 2),
(5, '2023-08-29-130121', 'App\\Database\\Migrations\\CreateBankDepositTable', 'default', 'App', 1693314325, 3),
(6, '2023-08-29-130632', 'App\\Database\\Migrations\\CreateBankWithdrawTable', 'default', 'App', 1693314497, 4),
(13, '2023-08-30-051417', 'App\\Database\\Migrations\\CreateBrandTable', 'default', 'App', 1693375265, 5),
(14, '2023-08-30-052222', 'App\\Database\\Migrations\\CreateChaqueTable', 'default', 'App', 1693375265, 5),
(16, '2023-08-30-061545', 'App\\Database\\Migrations\\CreateCustomersTable', 'default', 'App', 1693376996, 6),
(17, '2023-08-30-113923', 'App\\Database\\Migrations\\CreateCustomerTypeTable', 'default', 'App', 1693396448, 7),
(19, '2023-08-31-035553', 'App\\Database\\Migrations\\CreateEmployeeTable', 'default', 'App', 1693454627, 8),
(20, '2023-09-02-040549', 'App\\Database\\Migrations\\CreateGeneralSettingsTable', 'default', 'App', 1693627691, 9),
(21, '2023-09-02-041941', 'App\\Database\\Migrations\\CreateGeneralSettingsSuper', 'default', 'App', 1693628522, 10),
(23, '2023-09-02-052043', 'App\\Database\\Migrations\\CreateInvoiceTable', 'default', 'App', 1693633627, 11),
(25, '2023-09-02-055851', 'App\\Database\\Migrations\\CreateInvoiceItemTable', 'default', 'App', 1693636404, 12),
(27, '2023-09-02-064307', 'App\\Database\\Migrations\\CreateLcTable', 'default', 'App', 1693637263, 13),
(28, '2023-09-02-064843', 'App\\Database\\Migrations\\CreateLedgerTable', 'default', 'App', 1693637827, 14),
(29, '2023-09-02-114902', 'App\\Database\\Migrations\\CreateLedgerBankTable', 'default', 'App', 1693655916, 15),
(30, '2023-09-02-120046', 'App\\Database\\Migrations\\CreateLedgerCapitalTable', 'default', 'App', 1693656198, 16),
(31, '2023-09-02-120438', 'App\\Database\\Migrations\\CreateLedgerDiscountTable', 'default', 'App', 1693656612, 17),
(32, '2023-09-02-121229', 'App\\Database\\Migrations\\CreateLedgerEmployeeTable', 'default', 'App', 1693656947, 18),
(33, '2023-09-02-121818', 'App\\Database\\Migrations\\CreateLedgerExpenseTable', 'default', 'App', 1693657241, 19),
(34, '2023-09-02-122309', 'App\\Database\\Migrations\\CreateLedgerLoanTable', 'default', 'App', 1693657539, 20),
(36, '2023-09-02-131316', 'App\\Database\\Migrations\\CreateLedgerCashTable', 'default', 'App', 1693661001, 21),
(37, '2023-09-02-132543', 'App\\Database\\Migrations\\CreateLedgerOtherSalesTable', 'default', 'App', 1693661572, 22),
(38, '2023-09-02-133416', 'App\\Database\\Migrations\\CreateLedgerProfitTable', 'default', 'App', 1693661976, 23),
(39, '2023-09-02-134140', 'App\\Database\\Migrations\\CreateLedgerPurchaseTable', 'default', 'App', 1693662392, 24),
(40, '2023-09-02-134827', 'App\\Database\\Migrations\\CreateLedgerSalesTable', 'default', 'App', 1693662675, 25),
(41, '2023-09-02-135213', 'App\\Database\\Migrations\\CreateLedgerStockTable', 'default', 'App', 1693662893, 26),
(42, '2023-09-02-135626', 'App\\Database\\Migrations\\CreateLedgerSuppliersTable', 'default', 'App', 1693663221, 27),
(43, '2023-09-02-140208', 'App\\Database\\Migrations\\CreateLedgerVatTable', 'default', 'App', 1693663488, 28),
(44, '2023-09-05-043422', 'App\\Database\\Migrations\\CreateLicenseTable', 'default', 'App', 1693888703, 29),
(46, '2023-09-05-044711', 'App\\Database\\Migrations\\CreateAccountHeadTable', 'default', 'App', 1693890038, 30),
(47, '2023-09-05-050915', 'App\\Database\\Migrations\\CreateMoneyReceiptTable', 'default', 'App', 1693890807, 31),
(48, '2023-09-06-034629', 'App\\Database\\Migrations\\CreatePackageTable', 'default', 'App', 1693972265, 32),
(49, '2023-09-09-035823', 'App\\Database\\Migrations\\CreatePaymentTypeTable', 'default', 'App', 1694232050, 33),
(50, '2023-09-09-040712', 'App\\Database\\Migrations\\CreateProductsTable', 'default', 'App', 1694233613, 34),
(51, '2023-09-09-130211', 'App\\Database\\Migrations\\CreateProductCategoryTable', 'default', 'App', 1694264990, 35),
(52, '2023-09-09-133650', 'App\\Database\\Migrations\\CreatePurchaseTable', 'default', 'App', 1694266921, 36),
(53, '2023-09-09-134518', 'App\\Database\\Migrations\\CreatePurchaseItemTable', 'default', 'App', 1694267376, 37),
(54, '2023-09-16-033102', 'App\\Database\\Migrations\\CreateReturnPurchaseTable', 'default', 'App', 1694835937, 38),
(55, '2023-09-16-034720', 'App\\Database\\Migrations\\CreateReturnPurchaseItemTable', 'default', 'App', 1694836411, 39),
(57, '2023-09-16-041635', 'App\\Database\\Migrations\\CreateReturnSaleTable', 'default', 'App', 1694838173, 40),
(58, '2023-09-16-042450', 'App\\Database\\Migrations\\CreateReturnSaleItemTable', 'default', 'App', 1694838555, 41),
(59, '2023-09-16-103104', 'App\\Database\\Migrations\\CreateRoleTable', 'default', 'App', 1694860525, 42),
(60, '2023-09-16-103740', 'App\\Database\\Migrations\\CreateSalesTable', 'default', 'App', 1694860842, 43),
(61, '2023-09-16-104244', 'App\\Database\\Migrations\\CreateShopsTable', 'default', 'App', 1694861576, 44),
(62, '2023-09-16-115122', 'App\\Database\\Migrations\\CreateStoresTable', 'default', 'App', 1694865560, 45),
(63, '2023-10-01-042738', 'App\\Database\\Migrations\\CreateSuppliersTable', 'default', 'App', 1696134719, 46),
(64, '2023-10-01-043628', 'App\\Database\\Migrations\\CreateTransactionTable', 'default', 'App', 1696135481, 47),
(65, '2023-10-01-045006', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', 1696136118, 48),
(66, '2023-10-01-045745', 'App\\Database\\Migrations\\CreateVatRegisterTable', 'default', 'App', 1696136443, 49),
(67, '2023-10-01-050151', 'App\\Database\\Migrations\\CreateWarrantyManageTable', 'default', 'App', 1696136714, 50);

-- --------------------------------------------------------

--
-- Table structure for table `money_receipt`
--

CREATE TABLE `money_receipt` (
  `money_receipt_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` float UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `package_id` int(10) UNSIGNED NOT NULL,
  `package_name` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `package_all_permission` text COLLATE utf8_unicode_ci NOT NULL,
  `package_admin_permission` text COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Active','Inactive') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `permission` text COLLATE utf8_unicode_ci NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `sch_id`, `role`, `permission`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 2, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Pages\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_item\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_deposit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_withdraw\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Warranty_manage\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\",\"vat_option\":\"1\"},\"Role\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Money_receipt\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Loan_provider\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_nagodan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_loan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stores\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\"},\"Expense_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Balance_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc_installment\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customer_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Products\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Transaction\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chaque\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stock_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Daily_book\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_sale\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vat_register\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_vat\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Acquisition_due\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Owe_amount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Trial_balance\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_profit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_stock\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_expense\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"HeadToheadTransfer\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_other_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_discount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Previous_data_show\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_service_charge\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', '1', '2023-10-02 07:24:29', 1, NULL, '2024-12-26 18:52:26', NULL, NULL),
(3, 3, 'Admin', '{\"Dashboard\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Pages\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_item\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Product_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_deposit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Settings\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Bank_withdraw\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Warranty_manage\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\",\"vat_option\":\"1\"},\"Role\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Money_receipt\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Loan_provider\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_suppliers\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_nagodan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_loan\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"User\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stores\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_bank\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\",\"discount\":\"1\",\"warranty\":\"1\"},\"Expense_category\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Balance_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc_installment\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Lc\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Customer_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Products\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Transaction\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Chaque\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Stock_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Sales_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Purchase_report\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Daily_book\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Brand\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_employee\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_sale\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Return_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Vat_register\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_vat\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Acquisition_due\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Owe_amount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_purchase\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Trial_balance\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_capital\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_profit\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_stock\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_expense\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"HeadToheadTransfer\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_other_sales\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_discount\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Previous_data_show\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_type\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Service_invoice\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"},\"Ledger_service_charge\":{\"mod_access\":\"1\",\"create\":\"1\",\"read\":\"1\",\"update\":\"1\",\"delete\":\"1\"}}', '1', '2023-10-03 09:36:23', 1, NULL, '2024-12-26 18:52:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shops`
--

CREATE TABLE `shops` (
  `sch_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cash` float UNSIGNED NOT NULL COMMENT 'This is the nagad cash of the shop owner.',
  `capital` float DEFAULT NULL,
  `profit` float DEFAULT NULL,
  `service_charge` float DEFAULT NULL,
  `stockAmount` float DEFAULT NULL,
  `expense` float DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `purchase_balance` float NOT NULL,
  `sale_balance` float NOT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `logo` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `opening_status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `shops`
--

INSERT INTO `shops` (`sch_id`, `name`, `email`, `cash`, `capital`, `profit`, `service_charge`, `stockAmount`, `expense`, `discount`, `purchase_balance`, `sale_balance`, `address`, `mobile`, `comment`, `logo`, `image`, `package_id`, `status`, `opening_status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(2, 'Khan', 'khan@gmail.com', 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '1', '0', '2023-10-02 19:24:29', NULL, NULL, '2025-12-27 11:53:00', NULL, NULL),
(3, 'murad', 'murad@gmail.com', 49501, -50000, 0, 0, 140000, 0, 0, 140000, 0, '', '1923121212', '', 'profile_1735210605_882fcfce2769d5b0e220.png', 'pro_1723435084_4bc1901ff94b73aaee24.jpg', NULL, '1', '1', '2023-10-03 09:36:23', NULL, 2, '2026-03-09 12:27:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `supplier_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `balance` float NOT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `sch_id`, `name`, `balance`, `address`, `phone`, `status`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(23, 3, 'murad', -140000, NULL, '01714070771', '1', '2026-03-08 04:22:12', 2, 2, '2026-03-08 16:22:54', NULL, NULL),
(24, 3, 'murad', 500, NULL, '01714070774', '1', '2026-03-09 11:21:04', 2, 2, '2026-03-09 11:22:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `trans_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `trangaction_type` enum('Dr.','Cr.') COLLATE utf8_unicode_ci NOT NULL,
  `amount` float UNSIGNED NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `loan_pro_id` int(11) DEFAULT NULL,
  `bank_id` int(11) DEFAULT NULL,
  `bank_to_id` int(11) DEFAULT NULL COMMENT 'this is only used on fund transfer from bank to bank ',
  `lc_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `employee_id` int(11) DEFAULT NULL,
  `vat_id` int(11) DEFAULT NULL,
  `memo_number` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`trans_id`, `sch_id`, `title`, `description`, `trangaction_type`, `amount`, `customer_id`, `loan_pro_id`, `bank_id`, `bank_to_id`, `lc_id`, `supplier_id`, `employee_id`, `vat_id`, `memo_number`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(121, 3, 'Salary', NULL, 'Cr.', 4000, NULL, NULL, NULL, NULL, NULL, NULL, 8, NULL, NULL, '2026-03-08 10:43:03', 2, NULL, '2026-03-08 11:01:29', NULL, NULL),
(122, 3, '10000', NULL, 'Dr.', 10000.5, NULL, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-08 12:33:05', 2, NULL, '2026-03-09 10:06:06', NULL, NULL),
(123, 3, 'test', NULL, 'Cr.', 500, NULL, NULL, NULL, NULL, NULL, 24, NULL, NULL, NULL, '2026-03-09 11:21:15', 2, NULL, '2026-03-09 11:22:44', NULL, NULL),
(124, 3, 'test', NULL, 'Cr.', 500.5, 29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-03-09 11:21:40', 2, NULL, '2026-03-09 12:27:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_edit_log`
--

CREATE TABLE `transaction_edit_log` (
  `transaction_log_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `colum_name` varchar(255) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `old_amount` decimal(10,2) DEFAULT NULL,
  `new_amount` decimal(10,2) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_edit_log`
--

INSERT INTO `transaction_edit_log` (`transaction_log_id`, `sch_id`, `table_name`, `colum_name`, `id`, `trans_id`, `user_id`, `invoice_id`, `purchase_id`, `old_amount`, `new_amount`, `createdDtm`) VALUES
(359, 3, 'transaction', NULL, 0, 121, 2, NULL, NULL, '1000.00', '1000.00', '2026-03-08 10:58:58'),
(360, 3, 'transaction', NULL, 0, 121, 2, NULL, NULL, '1000.00', '1100.00', '2026-03-08 10:59:13'),
(361, 3, 'transaction', NULL, 0, 121, 2, NULL, NULL, '1100.00', '1000.00', '2026-03-08 10:59:34'),
(362, 3, 'transaction', NULL, 0, 121, 2, NULL, NULL, '1000.00', '5000.00', '2026-03-08 10:59:49'),
(363, 3, 'transaction', NULL, 0, 121, 2, NULL, NULL, '5000.00', '4000.00', '2026-03-08 11:01:29'),
(364, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '11000.00', '2026-03-08 12:19:04'),
(365, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '11000.00', '2026-03-08 12:22:04'),
(366, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '11000.00', '2026-03-08 12:22:11'),
(367, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '11000.00', '2026-03-08 12:22:46'),
(368, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '11000.00', '2026-03-08 12:23:36'),
(369, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '10000.00', '2026-03-08 12:23:46'),
(370, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '10000.00', '2026-03-08 12:24:57'),
(371, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '11000.00', '2026-03-08 12:25:07'),
(380, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '10000.00', '2026-03-08 12:31:32'),
(381, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '10000.00', '2026-03-08 12:31:42'),
(382, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '10000.00', '2026-03-08 12:31:49'),
(383, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '11000.00', '2026-03-08 12:32:01'),
(384, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '10000.00', '2026-03-08 12:35:13'),
(385, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '15000.00', '2026-03-08 12:35:32'),
(386, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '11000.00', '2026-03-08 12:36:43'),
(387, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '11000.00', '15000.00', '2026-03-08 12:38:17'),
(388, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '14000.00', '2026-03-08 12:38:40'),
(389, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '14000.00', '15000.00', '2026-03-08 12:40:17'),
(390, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '15000.00', '2026-03-08 12:42:52'),
(391, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '15000.00', '2026-03-08 12:43:00'),
(392, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '14000.00', '2026-03-08 12:43:10'),
(394, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '14000.00', '15000.00', '2026-03-08 12:46:10'),
(395, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '16000.00', '2026-03-08 12:48:43'),
(396, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '16000.00', '15000.00', '2026-03-08 12:48:55'),
(397, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '10000.00', '2026-03-08 12:49:15'),
(398, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '10000.00', '15000.00', '2026-03-08 12:53:30'),
(399, 3, 'bank_deposit', NULL, 12, 0, 2, NULL, NULL, '15000.00', '10000.00', '2026-03-08 12:54:06'),
(400, 3, 'bank_withdraw', NULL, 8, 0, 2, NULL, NULL, '5000.00', '4000.00', '2026-03-08 12:57:10'),
(401, 3, 'bank_withdraw', NULL, 8, 0, 2, NULL, NULL, '4000.00', '5000.00', '2026-03-08 13:03:08'),
(402, 3, 'bank_withdraw', NULL, 8, 0, 2, NULL, NULL, '5000.00', '4000.00', '2026-03-08 13:04:35'),
(403, 3, 'bank_withdraw', NULL, 8, 0, 2, NULL, NULL, '4000.00', '5000.00', '2026-03-08 13:04:48'),
(409, 3, 'transaction', NULL, 0, 122, 2, NULL, NULL, '10000.00', '10000.50', '2026-03-09 10:06:06'),
(410, 3, 'transaction', NULL, 0, 124, 2, NULL, NULL, '500.00', '500.50', '2026-03-09 11:21:52'),
(411, 3, 'transaction', NULL, 0, 124, 2, NULL, NULL, '500.50', '500.00', '2026-03-09 11:22:13'),
(412, 3, 'transaction', NULL, 0, 123, 2, NULL, NULL, '500.00', '500.50', '2026-03-09 11:22:29'),
(413, 3, 'transaction', NULL, 0, 123, 2, NULL, NULL, '500.50', '500.00', '2026-03-09 11:22:44'),
(418, 3, 'transaction', NULL, 0, 124, 2, NULL, NULL, '500.00', '500.50', '2026-03-09 12:27:26');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_log`
--

CREATE TABLE `transaction_log` (
  `transaction_log_id` int(11) NOT NULL,
  `sch_id` int(11) NOT NULL,
  `table_name` varchar(100) NOT NULL,
  `colum_name` varchar(255) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `trans_id` int(11) DEFAULT NULL,
  `dep_id` int(11) DEFAULT NULL,
  `wthd_id` int(11) DEFAULT NULL,
  `invoice_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_log`
--

INSERT INTO `transaction_log` (`transaction_log_id`, `sch_id`, `table_name`, `colum_name`, `id`, `trans_id`, `dep_id`, `wthd_id`, `invoice_id`, `purchase_id`, `amount`, `createdDtm`) VALUES
(378, 3, 'transaction', NULL, 121, 121, NULL, NULL, NULL, NULL, '4000.00', '2026-03-08 10:43:03'),
(379, 3, 'ledger_employee', NULL, 9, 121, NULL, NULL, NULL, NULL, '4000.00', '2026-03-08 10:43:03'),
(380, 3, 'employee', NULL, 8, 121, NULL, NULL, NULL, NULL, '4000.00', '2026-03-08 10:43:03'),
(381, 3, 'shops', NULL, 3, 121, NULL, NULL, NULL, NULL, '4000.00', '2026-03-08 10:43:03'),
(382, 3, 'ledger_nagodan', NULL, 70, 121, NULL, NULL, NULL, NULL, '4000.00', '2026-03-08 10:43:03'),
(383, 3, 'bank_deposit', NULL, 12, NULL, 12, NULL, NULL, NULL, '10000.00', '2026-03-08 11:01:05'),
(384, 3, 'shops', NULL, 3, NULL, 12, NULL, NULL, NULL, '10000.00', '2026-03-08 11:01:05'),
(385, 3, 'ledger_nagodan', NULL, 71, NULL, 12, NULL, NULL, NULL, '10000.00', '2026-03-08 11:01:05'),
(386, 3, 'bank', NULL, 12, NULL, 12, NULL, NULL, NULL, '10000.00', '2026-03-08 11:01:05'),
(387, 3, 'ledger_bank', NULL, 33, NULL, 12, NULL, NULL, NULL, '10000.00', '2026-03-08 11:01:05'),
(388, 3, 'transaction', NULL, 122, 122, NULL, NULL, NULL, NULL, '10000.50', '2026-03-08 12:33:05'),
(389, 3, 'ledger_loan', NULL, 29, 122, NULL, NULL, NULL, NULL, '10000.50', '2026-03-08 12:33:05'),
(390, 3, 'loan_provider', NULL, 22, 122, NULL, NULL, NULL, NULL, '10000.50', '2026-03-08 12:33:05'),
(391, 3, 'shops', NULL, 3, 122, NULL, NULL, NULL, NULL, '10000.50', '2026-03-08 12:33:05'),
(392, 3, 'ledger_nagodan', NULL, 72, 122, NULL, NULL, NULL, NULL, '10000.50', '2026-03-08 12:33:05'),
(393, 3, 'bank_deposit', NULL, 13, NULL, 13, NULL, NULL, NULL, '500.00', '2026-03-08 12:36:25'),
(394, 3, 'shops', NULL, 3, NULL, 13, NULL, NULL, NULL, '500.00', '2026-03-08 12:36:25'),
(395, 3, 'ledger_nagodan', NULL, 73, NULL, 13, NULL, NULL, NULL, '500.00', '2026-03-08 12:36:25'),
(396, 3, 'bank', NULL, 12, NULL, 13, NULL, NULL, NULL, '500.00', '2026-03-08 12:36:25'),
(397, 3, 'ledger_bank', NULL, 34, NULL, 13, NULL, NULL, NULL, '500.00', '2026-03-08 12:36:25'),
(398, 3, 'bank_withdraw', NULL, 8, NULL, NULL, 8, NULL, NULL, '5000.00', '2026-03-08 12:56:32'),
(399, 3, 'bank', NULL, 12, NULL, NULL, 8, NULL, NULL, '5000.00', '2026-03-08 12:56:32'),
(400, 3, 'ledger_bank', NULL, 35, NULL, NULL, 8, NULL, NULL, '5000.00', '2026-03-08 12:56:32'),
(401, 3, 'shops', NULL, 3, NULL, NULL, 8, NULL, NULL, '5000.00', '2026-03-08 12:56:32'),
(402, 3, 'ledger_nagodan', NULL, 74, NULL, NULL, 8, NULL, NULL, '5000.00', '2026-03-08 12:56:32'),
(403, 3, 'suppliers', NULL, 23, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(404, 3, 'ledger_suppliers', NULL, 45, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(405, 3, 'shops', 'purchase_balance', 3, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(406, 3, 'ledger_purchase', NULL, 12, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(407, 3, 'shops', 'stockAmount', 3, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(408, 3, 'ledger_stock', NULL, 25, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(409, 3, 'products', NULL, 18, NULL, NULL, NULL, NULL, 14, '1400.00', '2026-03-08 16:22:54'),
(410, 3, 'purchase_item', NULL, 18, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(411, 3, 'purchase', NULL, 14, NULL, NULL, NULL, NULL, 14, '140000.00', '2026-03-08 16:22:54'),
(412, 3, 'products', 'quantity', 18, NULL, NULL, NULL, 15, NULL, '1.00', '2026-03-08 16:24:15'),
(413, 3, 'shops', 'sale_balance', 3, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(414, 3, 'ledger_sales', 'sale_balance', 14, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(415, 3, 'invoice_id', 'profit', 15, NULL, NULL, NULL, 15, NULL, NULL, '2026-03-08 16:24:15'),
(416, 3, 'shops', 'profit', 3, NULL, NULL, NULL, 15, NULL, '100.00', '2026-03-08 16:24:15'),
(417, 3, 'ledger_profit', NULL, 14, NULL, NULL, NULL, 15, NULL, '100.00', '2026-03-08 16:24:15'),
(418, 3, 'shops', 'stockAmount', 3, NULL, NULL, NULL, 15, NULL, '1400.00', '2026-03-08 16:24:15'),
(419, 3, 'ledger_stock', NULL, 26, NULL, NULL, NULL, 15, NULL, '1400.00', '2026-03-08 16:24:15'),
(420, 3, 'customers', NULL, 28, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(421, 3, 'ledger', NULL, 55, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(422, 3, 'shops', 'cash', 3, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(423, 3, 'ledger_nagodan', NULL, 75, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(424, 3, 'customers', NULL, 28, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(425, 3, 'ledger', NULL, 56, NULL, NULL, NULL, 15, NULL, '1500.00', '2026-03-08 16:24:15'),
(426, 3, 'transaction', NULL, 123, 123, NULL, NULL, NULL, NULL, '500.00', '2026-03-09 11:21:15'),
(427, 3, 'ledger_suppliers', NULL, 46, 123, NULL, NULL, NULL, NULL, '500.00', '2026-03-09 11:21:16'),
(428, 3, 'suppliers', NULL, 24, 123, NULL, NULL, NULL, NULL, '500.00', '2026-03-09 11:21:16'),
(429, 3, 'shops', NULL, 3, 123, NULL, NULL, NULL, NULL, '500.00', '2026-03-09 11:21:16'),
(430, 3, 'ledger_nagodan', NULL, 77, 123, NULL, NULL, NULL, NULL, '500.00', '2026-03-09 11:21:16'),
(431, 3, 'transaction', NULL, 124, 124, NULL, NULL, NULL, NULL, '500.50', '2026-03-09 11:21:40'),
(432, 3, 'customers', NULL, 29, 124, NULL, NULL, NULL, NULL, '500.50', '2026-03-09 11:21:40'),
(433, 3, 'ledger', NULL, 59, 124, NULL, NULL, NULL, NULL, '500.50', '2026-03-09 11:21:40'),
(434, 3, 'ledger_nagodan', NULL, 78, 124, NULL, NULL, NULL, NULL, '500.50', '2026-03-09 11:21:40'),
(435, 3, 'shops', NULL, 3, 124, NULL, NULL, NULL, NULL, '500.50', '2026-03-09 11:21:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pic` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `permission` text COLLATE utf8_unicode_ci NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `sch_id`, `email`, `password`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `is_default`, `permission`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 2, 'khan@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'Khan', NULL, NULL, '', 2, '1', '1', '', '2023-10-02 07:24:29', 1, NULL, '2023-10-02 19:25:49', NULL, NULL),
(2, 3, 'murad@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', 'murad', NULL, NULL, '', 3, '1', '1', '', '2023-10-03 09:36:23', 1, NULL, '2023-10-03 09:36:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vat_register`
--

CREATE TABLE `vat_register` (
  `vat_id` int(10) UNSIGNED NOT NULL,
  `sch_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8_unicode_ci NOT NULL,
  `vat_register_no` varchar(155) COLLATE utf8_unicode_ci DEFAULT NULL,
  `balance` float NOT NULL,
  `is_default` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `createdDtm` datetime NOT NULL DEFAULT current_timestamp(),
  `createdBy` int(11) DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vat_register`
--

INSERT INTO `vat_register` (`vat_id`, `sch_id`, `name`, `vat_register_no`, `balance`, `is_default`, `createdDtm`, `createdBy`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 2, 'Default Vat Name', 'BIN-0000-01', 0, '1', '2023-10-02 07:24:29', 1, NULL, '2023-10-02 19:24:29', NULL, NULL),
(2, 3, 'BIN-0000-01', 'BIN-0000-01', 0, '1', '2023-10-03 09:36:23', 1, 2, '2026-01-08 10:12:09', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `mobile` (`mobile`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`bank_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `name` (`name`),
  ADD KEY `account_no` (`account_no`);

--
-- Indexes for table `bank_deposit`
--
ALTER TABLE `bank_deposit`
  ADD PRIMARY KEY (`dep_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `bank_id` (`bank_id`);

--
-- Indexes for table `bank_withdraw`
--
ALTER TABLE `bank_withdraw`
  ADD PRIMARY KEY (`wthd_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `bank_id` (`bank_id`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `chaque`
--
ALTER TABLE `chaque`
  ADD PRIMARY KEY (`chaque_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `mobile` (`mobile`),
  ADD KEY `cus_type_id` (`cus_type_id`);

--
-- Indexes for table `customer_type`
--
ALTER TABLE `customer_type`
  ADD PRIMARY KEY (`cus_type_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `gen_settings`
--
ALTER TABLE `gen_settings`
  ADD PRIMARY KEY (`settings_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `gen_settings_super`
--
ALTER TABLE `gen_settings_super`
  ADD PRIMARY KEY (`settings_id_sup`);

--
-- Indexes for table `ledger`
--
ALTER TABLE `ledger`
  ADD PRIMARY KEY (`ledg_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_bank`
--
ALTER TABLE `ledger_bank`
  ADD PRIMARY KEY (`ledgBank_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `money_receipt_id` (`money_receipt_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_purchase_id` (`rtn_purchase_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_capital`
--
ALTER TABLE `ledger_capital`
  ADD PRIMARY KEY (`capital_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `ledger_discount`
--
ALTER TABLE `ledger_discount`
  ADD PRIMARY KEY (`discount_ledg_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `ledger_employee`
--
ALTER TABLE `ledger_employee`
  ADD PRIMARY KEY (`ledg_emp_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `ledger_expense`
--
ALTER TABLE `ledger_expense`
  ADD PRIMARY KEY (`ledg_exp_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `memo_number` (`memo_number`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `ledger_loan`
--
ALTER TABLE `ledger_loan`
  ADD PRIMARY KEY (`ledg_loan_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `loan_pro_id` (`loan_pro_id`),
  ADD KEY `money_receipt_id` (`money_receipt_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `ledger_nagodan`
--
ALTER TABLE `ledger_nagodan`
  ADD PRIMARY KEY (`ledg_nagodan_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `loan_pro_id` (`loan_pro_id`),
  ADD KEY `money_receipt_id` (`money_receipt_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_purchase_id` (`rtn_purchase_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_other_sales`
--
ALTER TABLE `ledger_other_sales`
  ADD PRIMARY KEY (`ledg_oth_sales_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `ledger_profit`
--
ALTER TABLE `ledger_profit`
  ADD PRIMARY KEY (`profit_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `ledger_purchase`
--
ALTER TABLE `ledger_purchase`
  ADD PRIMARY KEY (`ledgPurch_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `rtn_purchase_id` (`rtn_purchase_id`);

--
-- Indexes for table `ledger_sales`
--
ALTER TABLE `ledger_sales`
  ADD PRIMARY KEY (`ledgSale_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `rtn_sale_id` (`rtn_sale_id`);

--
-- Indexes for table `ledger_service_charge`
--
ALTER TABLE `ledger_service_charge`
  ADD PRIMARY KEY (`ledger_service_charge_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `trans_id` (`service_invoice_id`);

--
-- Indexes for table `ledger_stock`
--
ALTER TABLE `ledger_stock`
  ADD PRIMARY KEY (`stock_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `purchase_id` (`purchase_id`);

--
-- Indexes for table `ledger_suppliers`
--
ALTER TABLE `ledger_suppliers`
  ADD PRIMARY KEY (`ledg_sup_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `money_receipt_id` (`money_receipt_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `rtn_purchase_id` (`rtn_purchase_id`);

--
-- Indexes for table `ledger_vat`
--
ALTER TABLE `ledger_vat`
  ADD PRIMARY KEY (`ledg_vat_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `vat_id` (`vat_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `trans_id` (`trans_id`);

--
-- Indexes for table `license`
--
ALTER TABLE `license`
  ADD PRIMARY KEY (`lic_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `loan_provider`
--
ALTER TABLE `loan_provider`
  ADD PRIMARY KEY (`loan_pro_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `phone` (`phone`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `money_receipt`
--
ALTER TABLE `money_receipt`
  ADD PRIMARY KEY (`money_receipt_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `shops`
--
ALTER TABLE `shops`
  ADD PRIMARY KEY (`sch_id`),
  ADD KEY `email` (`email`),
  ADD KEY `package_id` (`package_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`supplier_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `phone` (`phone`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`trans_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `loan_pro_id` (`loan_pro_id`),
  ADD KEY `bank_id` (`bank_id`),
  ADD KEY `lc_id` (`lc_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `vat_id` (`vat_id`);

--
-- Indexes for table `transaction_edit_log`
--
ALTER TABLE `transaction_edit_log`
  ADD PRIMARY KEY (`transaction_log_id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `transaction_log`
--
ALTER TABLE `transaction_log`
  ADD PRIMARY KEY (`transaction_log_id`),
  ADD KEY `id` (`id`),
  ADD KEY `table_name` (`table_name`),
  ADD KEY `table_name_2` (`table_name`,`id`),
  ADD KEY `trans_id` (`trans_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `sch_id` (`sch_id`),
  ADD KEY `email` (`email`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vat_register`
--
ALTER TABLE `vat_register`
  ADD PRIMARY KEY (`vat_id`),
  ADD KEY `sch_id` (`sch_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `bank_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `bank_deposit`
--
ALTER TABLE `bank_deposit`
  MODIFY `dep_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `bank_withdraw`
--
ALTER TABLE `bank_withdraw`
  MODIFY `wthd_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `brand_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chaque`
--
ALTER TABLE `chaque`
  MODIFY `chaque_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `customer_type`
--
ALTER TABLE `customer_type`
  MODIFY `cus_type_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `gen_settings`
--
ALTER TABLE `gen_settings`
  MODIFY `settings_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `gen_settings_super`
--
ALTER TABLE `gen_settings_super`
  MODIFY `settings_id_sup` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ledger`
--
ALTER TABLE `ledger`
  MODIFY `ledg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `ledger_bank`
--
ALTER TABLE `ledger_bank`
  MODIFY `ledgBank_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `ledger_capital`
--
ALTER TABLE `ledger_capital`
  MODIFY `capital_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `ledger_discount`
--
ALTER TABLE `ledger_discount`
  MODIFY `discount_ledg_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ledger_employee`
--
ALTER TABLE `ledger_employee`
  MODIFY `ledg_emp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ledger_expense`
--
ALTER TABLE `ledger_expense`
  MODIFY `ledg_exp_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ledger_loan`
--
ALTER TABLE `ledger_loan`
  MODIFY `ledg_loan_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `ledger_nagodan`
--
ALTER TABLE `ledger_nagodan`
  MODIFY `ledg_nagodan_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `ledger_other_sales`
--
ALTER TABLE `ledger_other_sales`
  MODIFY `ledg_oth_sales_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ledger_profit`
--
ALTER TABLE `ledger_profit`
  MODIFY `profit_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ledger_purchase`
--
ALTER TABLE `ledger_purchase`
  MODIFY `ledgPurch_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `ledger_sales`
--
ALTER TABLE `ledger_sales`
  MODIFY `ledgSale_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ledger_service_charge`
--
ALTER TABLE `ledger_service_charge`
  MODIFY `ledger_service_charge_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ledger_stock`
--
ALTER TABLE `ledger_stock`
  MODIFY `stock_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `ledger_suppliers`
--
ALTER TABLE `ledger_suppliers`
  MODIFY `ledg_sup_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `ledger_vat`
--
ALTER TABLE `ledger_vat`
  MODIFY `ledg_vat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `license`
--
ALTER TABLE `license`
  MODIFY `lic_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `loan_provider`
--
ALTER TABLE `loan_provider`
  MODIFY `loan_pro_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `money_receipt`
--
ALTER TABLE `money_receipt`
  MODIFY `money_receipt_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `package_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `shops`
--
ALTER TABLE `shops`
  MODIFY `sch_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `supplier_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `trans_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `transaction_edit_log`
--
ALTER TABLE `transaction_edit_log`
  MODIFY `transaction_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=419;

--
-- AUTO_INCREMENT for table `transaction_log`
--
ALTER TABLE `transaction_log`
  MODIFY `transaction_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=436;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vat_register`
--
ALTER TABLE `vat_register`
  MODIFY `vat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
